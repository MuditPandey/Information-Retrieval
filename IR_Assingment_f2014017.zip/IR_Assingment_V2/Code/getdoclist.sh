cd $1
ls > $2/doclist
